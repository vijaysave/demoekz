﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace DemoEkz
{
    public partial class MainWindow : Window
    {
        private int currentPage = 0;
        private List<Request> requests;

        public MainWindow()
        {
            InitializeComponent();

            // Находим и присоединяем обработчики событий к кнопкам
            Button nextPageButton = this.FindName("nextPageButton") as Button;
            Button addButton = this.FindName("addButton") as Button;
            nextPageButton.Click += NextPageButton_Click;
            addButton.Click += AddButton_Click;

            // Инициализируем массивы с данными
            string[] equipmentList = { "Лампа", "Микроволновка", "Телевизор", "Пылесос", "Холодильник", "Утюг", "Фен", "Посудомоечная машина", "Чайник", "Утюг", "Миксер", "Кофемашина" };
            string[] descriptions = { "Мерцает свет", "Не греет", "Не включается", "Потрескавшаяся дверца", "Не охлаждает", "Протекает", "Не выдувает горячий воздух", "Не моет посуду", "Не закипает", "Не гладит", "Не вращается насадка", "Не капает кофе" };
            string[] customers = { "Петров А.И.", "Сидоров В.П.", "Иванов Г.С.", "Кузнецов Д.К.", "Смирнова Е.А.", "Лебедева Ж.В.", "Никитин З.П.", "Захарова И.М.", "Беляева К.И.", "Григорьева Л.А.", "Максимова М.Д.", "Федорова Н.В." };
            string[] serialNumbers = { "54321", "65432", "76543", "87654", "98765", "09876", "10987", "21098", "32109", "43210", "56789", "67890" };
            string[] dates = { "01.05", "03.05", "05.05", "07.05", "09.05", "11.05", "13.05", "15.05", "17.05", "19.05", "21.05", "23.05" };

            requests = new List<Request>();

            // Заполняем список запросов начальными данными
            for (int i = 0; i < equipmentList.Length; i++)
            {
                Request request = new Request
                {
                    RequestNumber = (i + 1).ToString(),
                    RequestEquipment = equipmentList[i],
                    RequestSerialNumber = serialNumbers[i],
                    RequestDescription = descriptions[i],
                    RequestExecutor = "",
                    RequestCustomer = customers[i],
                    RequestDate = dates[i],
                    RequestStatus = "Не выполнено",
                    IsDone = false,
                    RequestData = null
                };

                requests.Add(request);
            }
            UpdateRequests();
        }

        // Обработчик события для добавления нового запроса
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string newRequestNumber;
            if (requests.Count == 0)
            {
                newRequestNumber = "1";
            }
            else
            {
                int lastRequestNumber = int.Parse(requests.Last().RequestNumber);
                newRequestNumber = (lastRequestNumber + 1).ToString();
            }

            // Создаем новый объект запроса с данными от пользователя
            Request newRequest = new Request
            {
                RequestNumber = newRequestNumber,
                RequestEquipment = newRequestEquipment.Text,
                RequestSerialNumber = newRequestSerialNumber.Text,
                RequestDescription = newRequestDescription.Text,
                RequestExecutor = (newRequestExecutor.SelectedItem as TextBlock)?.Text ?? "",
                RequestCustomer = newRequestCustomer.Text,
                RequestDate = newRequestDate.Text,
                RequestStatus = "",
                IsDone = false,
                RequestData = null
            };

            // Добавляем новый запрос в список и обновляем отображение
            requests.Add(newRequest);
            UpdateRequests();
        }


        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, достигли ли конца списка запросов
            if (requests.Count / 8 == currentPage)
            {
                currentPage = 0; // Возвращаемся на первую страницу
            }
            else
            {
                currentPage++; // Переходим на следующую страницу
            }

            UpdateRequests(); // Обновляем отображение запросов
        }

        public void UpdateRequests()
        {
            int startIndex = currentPage * 8;
            int endIndex = Math.Min(startIndex + 8, requests.Count);

            // Обновляем данные для каждого элемента на странице
            for (int i = 0; i < 8; i++)
            {
                ComboBox executorComboBox = this.FindName($"ComboBoxExecutor{i + 1}") as ComboBox;
                ComboBox statusComboBox = this.FindName($"ComboBoxStatus{i + 1}") as ComboBox;

                // Сбрасываем выбранные значения и устанавливаем доступность
                executorComboBox.SelectedIndex = -1;
                statusComboBox.SelectedIndex = -1;
                executorComboBox.IsEnabled = i < endIndex - startIndex;
                statusComboBox.IsEnabled = i < endIndex - startIndex;

                TextBlock requestNumber = this.FindName($"requestNumber{i + 1}") as TextBlock;
                TextBlock requestEquipment = this.FindName($"requestEquipment{i + 1}") as TextBlock;
                TextBlock requestSerialNumber = this.FindName($"requestSerialNumber{i + 1}") as TextBlock;
                TextBlock requestDescription = this.FindName($"requestDescription{i + 1}") as TextBlock;
                TextBlock requestCustomer = this.FindName($"requestCustomer{i + 1}") as TextBlock;
                TextBlock requestDate = this.FindName($"requestDate{i + 1}") as TextBlock;

                if (i < endIndex - startIndex)
                {
                    // Заполняем данные для отображения запросов
                    requestNumber.Text = requests[startIndex + i].RequestNumber;
                    requestEquipment.Text = requests[startIndex + i].RequestEquipment;
                    requestSerialNumber.Text = requests[startIndex + i].RequestSerialNumber;
                    requestDescription.Text = requests[startIndex + i].RequestDescription;
                    requestCustomer.Text = requests[startIndex + i].RequestCustomer;
                    requestDate.Text = requests[startIndex + i].RequestDate;

                    // Устанавливаем выбранные значения для комбо-боксов
                    if (!string.IsNullOrEmpty(requests[startIndex + i].RequestExecutor))
                    {
                        executorComboBox.SelectedItem = executorComboBox.Items.OfType<TextBlock>().FirstOrDefault(tb => tb.Text == requests[startIndex + i].RequestExecutor);
                    }

                    if (!string.IsNullOrEmpty(requests[startIndex + i].RequestStatus))
                    {
                        statusComboBox.SelectedItem = statusComboBox.Items.OfType<TextBlock>().FirstOrDefault(tb => tb.Text == requests[startIndex + i].RequestStatus);
                    }
                }
                else
                {
                    // Если элемент не находится на текущей странице, очищаем данные
                    requestNumber.Text = "";
                    requestEquipment.Text = "";
                    requestSerialNumber.Text = "";
                    requestDescription.Text = "";
                    requestCustomer.Text = "";
                    requestDate.Text = "";
                }
            }

            // Обновляем статистику по запросам
            TextBlock countRequestTextBlock = this.FindName($"CountRequest") as TextBlock;
            TextBlock avgTimeTextBlock = this.FindName($"AvgTime") as TextBlock;
            TextBlock ratingClientsTextBlock = this.FindName($"RatingClients") as TextBlock;

            int countCompletedRequests = requests.Count(r => r.RequestStatus == "Выполнено");
            int totalExecutionTime = 0;
            int ratingClients = 0;

            // Вычисляем суммарное время выполнения и рейтинг клиентов
            foreach (var request in requests)
            {
                if (request.RequestData != null && !string.IsNullOrEmpty(request.RequestData.ExecutionTime))
                {
                    totalExecutionTime += int.Parse(request.RequestData.ExecutionTime);
                }

                if (request.RequestData != null && !string.IsNullOrEmpty(request.RequestData.CustomerRating))
                {
                    ratingClients += int.Parse(request.RequestData.CustomerRating);
                }
            }

            int avgTime = countCompletedRequests > 0 ? totalExecutionTime / countCompletedRequests : 0;

            // Обновляем отображение статистики
            countRequestTextBlock.Text = countCompletedRequests.ToString();
            avgTimeTextBlock.Text = avgTime.ToString();
            ratingClientsTextBlock.Text = ratingClients.ToString();
        }

        public Request? FindRequestByNumber(int requestNumber)
        {
            // Находим запрос по номеру
            return requests.FirstOrDefault(r => int.Parse(r.RequestNumber) == requestNumber);
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;
            if (comboBox != null)
            {
                TextBlock selectedTextBlock = comboBox.SelectedItem as TextBlock;
                if (selectedTextBlock != null)
                {
                    // Определяем индекс элемента в списке на основе имени ComboBox
                    int index = int.Parse(comboBox.Name.Substring(comboBox.Name.IndexOf(comboBox.Name.FirstOrDefault(char.IsDigit)))) - 1;
                    string comboBoxName = comboBox.Name;

                    if (comboBoxName.Contains("ComboBoxExecutor"))
                    {
                        // Обновляем исполнителя запроса
                        requests[currentPage * 8 + index].RequestExecutor = selectedTextBlock.Text;
                    }
                    if (comboBoxName.Contains("ComboBoxStatus"))
                    {
                        // Обновляем статус запроса
                        requests[currentPage * 8 + index].RequestStatus = selectedTextBlock.Text;
                    }

                    int startIndex = currentPage * 8;
                    int endIndex = Math.Min(startIndex + 8, requests.Count);

                    for (int i = 0; i < 8; i++)
                    {
                        if (startIndex + i < requests.Count)
                        {
                            // Проверяем статус запроса
                            if (requests[startIndex + i].RequestStatus == "Удалить")
                            {
                                // Удаляем запрос из списка
                                requests.RemoveAt(startIndex + i);
                                UpdateRequests();
                                return;
                            }
                            else if (requests[startIndex + i].RequestStatus == "Выполнено")
                            {
                                if (!requests[startIndex + i].IsDone)
                                {
                                    // Помечаем запрос как выполненный и отображаем дополнительную информацию
                                    UserControlRequest userControlRequest = this.FindName("userControlRequest") as UserControlRequest;
                                    userControlRequest.RequestNumber = int.Parse(requests[startIndex + i].RequestNumber);
                                    userControlRequest.RequestIndex = startIndex + i;
                                    userControlRequest.UpdateRequestNumberText();
                                    userControlRequest.FillFieldsWithRequestData();
                                    this.Height = 910;
                                    requests[startIndex + i].IsDone = true;
                                    return;
                                }
                            }
                            else
                            {
                                // Сбрасываем флаг выполнения запроса
                                requests[startIndex + i].IsDone = false;
                            }
                        }
                    }
                }
            }
        }
    }
}