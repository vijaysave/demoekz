﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoEkz
{
    public class RequestData
    {
        public string ExecutionTime { get; set; }
        public string CustomerRating { get; set; }
        public string WorkCost { get; set; }
        public string Materials { get; set; }
        public string MalfunctionReasons { get; set; }
        public string ExecutionProcess { get; set; }
    }

}
