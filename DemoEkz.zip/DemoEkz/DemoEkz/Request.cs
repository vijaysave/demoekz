﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoEkz
{
    public class Request
    {
        public string RequestNumber { get; set; }
        public string RequestEquipment { get; set; }
        public string RequestSerialNumber { get; set; }
        public string RequestDescription { get; set; }
        public string RequestExecutor { get; set; }
        public string RequestCustomer { get; set; }
        public string RequestDate { get; set; }
        public string RequestStatus { get; set; }
        public bool IsDone { get; set; }
        public RequestData RequestData { get; set; }
    }

}
