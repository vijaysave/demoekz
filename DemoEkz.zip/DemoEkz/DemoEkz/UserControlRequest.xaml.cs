﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoEkz
{
    public partial class UserControlRequest : UserControl
    {
        public int RequestNumber { get; set; }
        public int RequestIndex { get; set; }


        public UserControlRequest()
        {
            InitializeComponent();
            Button close = this.FindName("close") as Button;
            close.Click += Close_Click;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Window parentWindow = Window.GetWindow(this);
            MainWindow mainWindow = parentWindow as MainWindow;
            parentWindow.Height = 480;

            string executionTime = ExecutionTimeTextBox.Text;
            string customerRating = CustomerRatingTextBox.Text;
            string workCost = WorkCostTextBox.Text;
            string materials = MaterialsTextBox.Text;
            string malfunctionReasons = MalfunctionReasonsTextBox.Text;
            string executionProcess = ExecutionProcessTextBox.Text;

            RequestData data = new RequestData
            {
                ExecutionTime = executionTime,
                CustomerRating = customerRating,
                WorkCost = workCost,
                Materials = materials,
                MalfunctionReasons = malfunctionReasons,
                ExecutionProcess = executionProcess
            };


            Request request = mainWindow.FindRequestByNumber(RequestNumber);

            if (request != null)
            {
                request.RequestData = data;
            }

            mainWindow.UpdateRequests();
        }

        public void UpdateRequestNumberText()
        {
            labelRequestNumber.Content = "Заявка №" + RequestNumber;
            
        }

        public void FillFieldsWithRequestData()

        {
            ExecutionTimeTextBox.Text = "";
            CustomerRatingTextBox.Text = "";
            WorkCostTextBox.Text = "";
            MaterialsTextBox.Text = "";
            MalfunctionReasonsTextBox.Text = "";
            ExecutionProcessTextBox.Text = "";
            Window parentWindow = Window.GetWindow(this);
            MainWindow mainWindow = parentWindow as MainWindow;
            Request request = mainWindow.FindRequestByNumber(RequestNumber);

            if (request != null && request.RequestData != null)
            {
                RequestData requestData = request.RequestData as RequestData;

                if (requestData != null)
                {
                    ExecutionTimeTextBox.Text = requestData.ExecutionTime;
                    CustomerRatingTextBox.Text = requestData.CustomerRating;
                    WorkCostTextBox.Text = requestData.WorkCost;
                    MaterialsTextBox.Text = requestData.Materials;
                    MalfunctionReasonsTextBox.Text = requestData.MalfunctionReasons;
                    ExecutionProcessTextBox.Text = requestData.ExecutionProcess;
                }
            }
        }
    }
}
